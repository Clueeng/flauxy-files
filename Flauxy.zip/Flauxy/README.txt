UNLESS YOU CARE ABOUT CHANGING ACCOUNTS IN GAME THIS DOES NOT APPLY TO YOU

V V V V V V V V V V V V V V V V V V V V V V V V V V V V V V V V V V V V V V


Due to some retarded update that breaks HTTPS requests above java 11+, please use java 8
I use temurin but as long as you use any java 8 it should be fine

If the client crashes for some JNI related error, try running it using java.exe and not javaw.exe

https://imgur.com/a/GXtpgFY